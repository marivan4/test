angular.module('app.controllers', [])
.controller('VeiculoController', VeiculoController)
.controller('RastrearVeiculosController', RastrearVeiculosController)
.controller('LoginController', LoginController)
.controller('MainController', MainController);

VeiculoController.$inject = ['VeiculoService', '$scope', '$location', '$ionicLoading', 'toastr'];
RastrearVeiculosController.$inject = ['VeiculoService', '$scope', '$location'];
LoginController.$inject = ['$scope', 'toastr', 'AuthService', '$ionicLoading'];
MainController.$inject = ['$scope', 'AuthService', '$location'];

function MainController($scope, AuthService, $location){
    $scope.logout = logout;

    function logout(){
        AuthService.logout();
        $location.path('#/login');
    }
}

function LoginController($scope, toastr, AuthService, $ionicLoading){
    $scope.logar = logar;
    $scope.credentials = {
        account: '',
        user: '',
        password: ''
    };

    function logar(){
        if(!$scope.credentials.account){
            toastr.error('É necessário informar a conta.');
            return;
        }

        if(!$scope.credentials.user){
            toastr.error('É necessário informar o usuário');
            return;
        }

        if(!$scope.credentials.password){
            toastr.error('É necessário informar a senha.');
            return;
        }

        $ionicLoading.show({
            template: '<ion-spinner icon="ripple" class="spinner-energized"></ion-spinner>',
            content: 'Autenticando...',
            animation: 'fade-in',
            showBackdrop: false,
            maxWidth: 200,
            showDelay: 0
          });

        AuthService.logar($scope.credentials).then(function(){
            $ionicLoading.hide();
        });
    }
}

function RastrearVeiculosController(VeiculoService, $scope, $location){
    var poly, id;

    iniciar();

    function iniciar(){
        id = $location.search().id
        VeiculoService.getVeiculos(id).then(getVeiculosResult);
    }

    function getLatLongPositions(events){
        var positions = [];
        for(var x = 0, y = events.length; x < y; x++){
            var position = {
                lat: events[x]['GPSPoint_lat'],
                lng: events[x]['GPSPoint_lon']            
            };
            
            positions.push(position);
        }

        return positions;
    }

    function setPolylineMarkerHistory(positions){
        var infowindow = new google.maps.InfoWindow();
        var lineSymbol = {
            path: google.maps.SymbolPath.CIRCLE,
            fillOpacity: 1,
            scale: 3
        };

        poly = new google.maps.Polyline({
            path: getLatLongPositions(positions),
            strokeColor: '#0eb7f6',
            strokeOpacity: 0,
            fillOpacity: 0,
            icons: [{
                icon: lineSymbol,
                offset: '0',
                repeat: '10px'
            }],
        });

        poly.setMap($scope.map);

        for(var x = 0, y = positions.length; x < y; x++){
            var position = {
                lat: positions[i]['GPSPoint_lat'],
                lng: positions[i]['GPSPoint_lon']            
            };

            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(position),
                map: $scope.map,
                icon: 'http://maps.google.com/mapfiles/ms/icons/yellow-dot.png',
                veiculo: positions[i]['Device'],
                motorista: positions[i]['DriverID'],
                endereco: positions[i]['Address'],
                status: positions[i]['StatusCode_desc'],
                velocidade: positions[i]['Speed'],
                odometro: positions[i]['Odometer']
              });

              google.maps.event.addListener(marker, 'click', (function(marker, i) {
                return function() {
                var contentString = '<div id="content">'+
                '<p>Latitude/Longitude: '+marker.position+'</p>'+
                '<p>Veículo: '+marker.veiculo+'</p>'+
                '<p>Motorista: '+marker.motorista+'</p>'+
                '<p>Endereço: '+marker.endereco+'</p>'+
                '<p>Status: '+marker.status+'</p>'+
                '<p>Velocidade: '+marker.velocidade+' Km/h</p>'+
                '<p>Odometro: '+marker.odometro+' Km </p>'+
                '</div>'; 
    
                infowindow.setContent(contentString);
                infowindow.open($scope.map, marker);
                }
              })(marker, i));
        } 
    }

    function getVeiculosResult(response){
        var latLng = new google.maps.LatLng(-23.533773, -46.625290);
    
        var mapOptions = {
           center: latLng,
           zoom: 15,
           mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        
        $scope.map = new google.maps.Map(document.getElementById("map"), mapOptions);

        $scope.veiculos = response.veiculos || [];

        var bounds = new google.maps.LatLngBounds();
        var infowindow = new google.maps.InfoWindow();    
        
        for (i = 0; i < $scope.veiculos.length; i++) {            
          var lastEventIndex = $scope.veiculos[i]['EventData'].length-1;
          
          if(!$scope.veiculos[i]['EventData'][lastEventIndex] || 
            !$scope.veiculos[i]['EventData'][lastEventIndex]['GPSPoint_lat'] || 
            !$scope.veiculos[i]['EventData'][lastEventIndex]['GPSPoint_lon']){
            continue;
          }

          var position = {
            lat: $scope.veiculos[i]['EventData'][lastEventIndex]['GPSPoint_lat'], //last position
            lng: $scope.veiculos[i]['EventData'][lastEventIndex]['GPSPoint_lon']  //last position          
          };
          
          var marker = new google.maps.Marker({
            position: new google.maps.LatLng(position),
            map: $scope.map,
            veiculo: $scope.veiculos[i]['Device_desc'],
            motorista: $scope.veiculos[i]['EventData'][lastEventIndex]['DriverID'],
            endereco: $scope.veiculos[i]['EventData'][lastEventIndex]['Address'],
            status: $scope.veiculos[i]['EventData'][lastEventIndex]['StatusCode_desc'],
            velocidade: $scope.veiculos[i]['EventData'][lastEventIndex]['Speed'],
            odometro: $scope.veiculos[i]['EventData'][lastEventIndex]['Odometer']
          });
        
          //extend the bounds to include each marker's position
          bounds.extend(marker.position);
        
          google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
            var contentString = '<div id="content">'+
            '<p>Latitude/Longitude: '+marker.position+'</p>'+
            '<p>Veículo: '+marker.veiculo+'</p>'+
            '<p>Motorista: '+marker.motorista+'</p>'+
            '<p>Endereço: '+marker.endereco+'</p>'+
            '<p>Status: '+marker.status+'</p>'+
            '<p>Velocidade: '+marker.velocidade+' Km/h</p>'+
            '<p>Odometro: '+marker.odometro+' Km </p>'+
            '</div>'; 

            infowindow.setContent(contentString);
            infowindow.open($scope.map, marker);
            }
          })(marker, i));
        }
        
        //now fit the map to the newly inclusive bounds
        $scope.map.fitBounds(bounds);
        
        //(optional) restore the zoom level after the map is done scaling
        var listener = google.maps.event.addListener($scope.map, "idle", function () {
            if(id && id !== 'all'){
                setPolylineMarkerHistory($scope.veiculos[0]['EventData']);
            }

            google.maps.event.removeListener(listener);
        });
    }
}

function VeiculoController(VeiculoService, $scope, $location, $ionicLoading, toastr){
    iniciar();

    $scope.rastrearVeiculo = rastrearVeiculo;
    $scope.getVeiculos = getVeiculos;
    $scope.isIgnicao = true;
    $scope.getEnderecoExato = getEnderecoExato;
    $scope.bloquearVeiculo = bloquearVeiculo;
    $scope.liberarVeiculo = liberarVeiculo;

    function bloquearVeiculo(car){
        $ionicLoading.show({
            template: '<ion-spinner icon="ripple" class="spinner-energized"></ion-spinner>',
            content: 'Loading',
            animation: 'fade-in',
            showBackdrop: false,
            maxWidth: 200,
            showDelay: 0
          });

        VeiculoService.bloquearVeiculo(car).then(bloquearVeiculoResult, bloquearVeiculoFault);
    }

    function bloquearVeiculoFault(){
        $ionicLoading.hide();
    }

    function bloquearVeiculoResult(){
        $ionicLoading.hide();
        toastr.success('Bloqueio enviado com sucesso!');
    }

    function liberarVeiculo(car){
        $ionicLoading.show({
            template: '<ion-spinner icon="ripple" class="spinner-energized"></ion-spinner>',
            content: 'Loading',
            animation: 'fade-in',
            showBackdrop: false,
            maxWidth: 200,
            showDelay: 0
          });

        VeiculoService.liberarVeiculo(car).then(liberarVeiculoResult, liberarVeiculoFault);
    }

    function liberarVeiculoFault(){
        $ionicLoading.hide();
    }

    function liberarVeiculoResult(){
        $ionicLoading.hide();
        toastr.success('Liberação enviado com sucesso!');
    }

    function iniciar(){
        getVeiculos();
    }

    function getEnderecoExato(car){
        VeiculoService.getEnderecoExato(car).then(function(endereco){
            toastr.warning('Endereço exato: '+endereco);
        });
    }

    function getVeiculos(){
        $ionicLoading.show({
        template: '<ion-spinner icon="ripple" class="spinner-energized"></ion-spinner>',
	    content: 'Loading',
	    animation: 'fade-in',
	    showBackdrop: false,
        maxWidth: 200,
	    showDelay: 0
	  });

        VeiculoService.getVeiculos('all').then(function(data){
            $ionicLoading.hide();
            $scope.cars = data.veiculos || [];
            
            //Stop the ion-refresher from spinning
            $scope.$broadcast('scroll.refreshComplete');
        });
    }

    function rastrearVeiculo(id){
        $location.path('/tab/rastrear/').search({id: id});
    }
}
