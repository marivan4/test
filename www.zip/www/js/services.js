angular.module('app.services', [])
  .service('AuthService', AuthService)
  .service('VeiculoService', VeiculoService);

var thisUrl = 'http://www.narrota.com:8063/getVeiculos';

function AuthService($localStorage, toastr, $state, $http){
    this.getToken = getToken;
    this.setToken = setToken;
    this.logout = logout;
    this.logar = logar;

    function getToken(){
        return $localStorage.token;
    }

    function setToken(token){
       $localStorage.token = token;
    }

    function logout(){
      delete $localStorage.token;
    }

    function logar(credentials){
      var params = {
        account: credentials.account,
        password: credentials.password,
        user: credentials.user,//AuthService.getToken().user,
        id: 'all'
      };
      
      return $http.post(thisUrl, params).then(function(response){
          if(response.data['Error']){
              toastr.error('Os credenciais estão incorreto.');
          }else{
            setToken(params);
            $state.go('tab.veiculos');
          }
      });  
    }
}

AuthService.$inject = ['$localStorage', 'toastr', '$state', '$http'];
VeiculoService.$inject = ['$http', 'AuthService', 'toastr', '$q'];

function VeiculoService($http, AuthService, toastr, $q){
    this.getVeiculos = getVeiculos;
    this.bloquearVeiculo = bloquearVeiculo;
    this.liberarVeiculo = liberarVeiculo;
    this.getEnderecoExato = getEnderecoExato;
    
    function getVeiculos(id){//se for 0 -> ALL
      var params = {
        account: AuthService.getToken().account,
        password: AuthService.getToken().password,
        user: AuthService.getToken().user,
        id: id
      };
      
      return $http.post(thisUrl, params).then(function(response){
          return formatarVeiculos(response.data);
      });
    }

    function bloquearVeiculo(car){
      var defer = $q.defer();

      var comandoBloqueio;

      if(!car.SimPhoneNumber){
        toastr.error('Não existe um Nº Sim(Chip) cadastrado para esse veículo.');
        defer.reject();
        return defer.promise;
      }

      if(car.Commands && 
        car.Commands.split('@') && 
        car.Commands.split('@').length > 1){
         comandoBloqueio = car.Commands.split('@')[0];
      }else{
        toastr.error('Os comandos de bloqueio/liberar estão cadastrados incorretos no sistema.');
        defer.reject();
        return defer.promise;
      }

      var codigo = 138;
      var token = 'f8f1ad20c13031773d43a590a19ef9dece241a47';
      var url = 'http://narrotasms.com/api/api_sms.php?codigo='+codigo+'&token='+token+'&textosms='+comandoBloqueio+'&numero='+car.SimPhoneNumber;

      $http.get(url).then(function(){
        defer.resolve();
      }, function(){
        defer.reject();
      });

      return defer.promise;
    }

    function getEnderecoExato(car){
        return $http.get('http://maps.googleapis.com/maps/api/geocode/json?latlng='+car['GPSPoint_lat']+','+car['GPSPoint_lon']+'&sensor=true').then(function(response){
          return response.data['results'][0]['formatted_address'];
        });
    }

    function liberarVeiculo(car){
      var defer = $q.defer();

      var comandoLiberar;

      if(!car.SimPhoneNumber){
        toastr.error('Não existe um Nº Sim(Chip) cadastrado para esse veículo.');
        defer.reject();
        return defer.promise;
      }

      if(car.Commands && 
        car.Commands.split('@') && 
        car.Commands.split('@').length > 1){
          comandoLiberar = car.Commands.split('@')[1];
      }else{
        toastr.error('Os comandos de bloqueio/liberar estão cadastrados incorretos no sistema.');
        defer.reject();
        return defer.promise;
      }
    
      var codigo = 138;
      var token = 'f8f1ad20c13031773d43a590a19ef9dece241a47';
      var url = 'http://narrotasms.com/api/api_sms.php?codigo='+codigo+'&token='+token+'&textosms='+comandoLiberar+'&numero='+car.SimPhoneNumber;

      $http.get(url).then(function(){
        defer.resolve();
      }, function(){
        defer.reject()
      });

      return defer.promise;
    }

    function formatarVeiculos(data){
      if(!data){
        return [];
      }

      var obj = {};
      obj.veiculos = data['DeviceList'];
      
      return obj;
    }
}